from django.shortcuts import render
from django.views.generic import TemplateView
#from .charts import objects_to_df, Chart
import time
import csv
import json
from django.http.response import JsonResponse
import datetime as dt
from pandas.plotting import scatter_matrix
import warnings
import seaborn as sns
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from io import BytesIO
import base64
import pandas as pd
from datetime import timedelta
import squarify
import numpy as np
from mpl_toolkits.mplot3d import Axes3D # 3d plot
from termcolor import colored as cl # text customization


#Predictive models
import sklearn.cluster as cluster
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
#from sklearn.mixture import GMM
from sklearn import mixture
from sklearn.metrics import silhouette_samples, silhouette_score
warnings.filterwarnings('ignore')


# Views go here.
def mainpage(request):

    import matplotlib.pyplot as plt
    # Reading the dataset and preview
    data_cleaned = pd.read_csv('customers/cust_seg_cleaned.csv')
    # Converting my date attribute to date format
    data_cleaned['InvoiceDate'] = pd.to_datetime(data_cleaned['InvoiceDate'])


    # no_transaction= data_cleaned['Invoice'].nunique()
    no_items_bought= data_cleaned['StockCode'].nunique()
    no_customers= data_cleaned['CustomerID'].nunique()
    no_country= data_cleaned['Country'].nunique()
    turnover= data_cleaned[data_cleaned.Value>0]['Value'].sum().round(2)
    # pd.options.display.float_format = '${:,.2f}'.format

    # removing cancelled orders to remove negative figures
    data_cleaned = data_cleaned[data_cleaned['Quantity'] > 0]
    # data_cleaned.shape

    ### RFM MODEEL ####
    # --Grouping  data by customerID--

    # Creating a snapshot date with plus 1 of the most recent date
    snapshot_date = data_cleaned['InvoiceDate'].max() + timedelta(days=1)
    # print(snapshot_date)
    # Grouping by CustomerID using the snapshot. The recencyu is the snapshot date minus the most recent date of the customer
    data_process = data_cleaned.groupby(['CustomerID']).agg({
        'InvoiceDate': lambda x: (snapshot_date - x.max()).days,
        'Invoice': 'count',
        'Value': 'sum'})
    # Rename the columns
    data_process.rename(columns={'InvoiceDate': 'Recency',
                                 'Invoice': 'Frequency',
                                 'Value': 'MonetaryValue'}, inplace=True)

    # plotting turnover per country
    Top10Country = data_cleaned[data_cleaned.Quantity > 0].groupby(['Country'])['Value'].sum().sort_values(
        ascending=False)[0:10]
    # print(Top10Country.to_json())

    data2 = {'x-data': Top10Country.index.tolist(), 'y-data': Top10Country.values.tolist()}

    # plotting number of turnover per customers
    Top10Customers = data_cleaned[data_cleaned.Value > 0].groupby(['CustomerID','Country'])['Value'].sum().sort_values(
        ascending=False)[0:10]
    Top10Customers.sort_values().plot(kind='bar').set_title('Turnover by Customer', fontsize=15)
    # print(Top10Country.to_json())

    data3 = {'x-data': Top10Customers.index.tolist(), 'y-data': Top10Customers.values.tolist()}
    # creating the pie chart of the percentage of sale value by the day of the week

    # creating the pie chart of the percentage of sale value by Month
    turnover_month = data_cleaned[data_cleaned.Value > 0].groupby(['InvoiceMonth'])['Value'].sum()
    turnover_month.plot( figsize=(7, 7)).set_title('Percantages of Sales Value by Months', fontsize=15)

    data4 = {'x-data': turnover_month.index.tolist(), 'y-data': turnover_month.values.tolist()}
    #data_cleaned.groupby('Day of week')['Value'].sum().plot(kind='pie', autopct='%.2f%%', figsize=(7, 7)).set(ylabel='')

    top_customer_freq = data_process.groupby(data_process.index)['Frequency'].sum().sort_values(ascending=False)[0:10]
    sns.barplot(y=top_customer_freq.values, x=top_customer_freq.index).set(xlabel='CustomerID', ylabel='Frequency')
    plt.title("Best Customers based on Frequency")
    data5 = {'x-data': top_customer_freq.index.tolist(), 'y-data': top_customer_freq.values.tolist()}


    context = {
        "no_country": no_country,
        "no_customers": no_customers,
        "no_items_bought": no_items_bought,
        "turnover": turnover,
        'data2': data2,
        'data3': data3,
        'data4': data4,
        'data5': data5,
    }
    #print (result,"This is our result")
    return render(request, 'customer/main.html', context)


# My Method for EDA
def visualization(request):
    import matplotlib.pyplot as plt
    # Reading the dataset and preview
    data_cleaned = pd.read_csv('customers/cust_seg_cleaned.csv')
    # Converting my date attribute to date format
    data_cleaned['InvoiceDate'] = pd.to_datetime(data_cleaned['InvoiceDate'])

    # create a charts context to hold all of the charts
    #context['charts'] = []

    #turnover_by_top_ten_country = Chart('country', chart_id='turnover_by_top_ten_country', palette=PALETTE)
    # plotting number of Turnover per country
    # create a pandas pivot_table based on the fields and aggregation we want
    # stacks are used for either grouping or stacking a certain column
    #turnover_by_top_ten_country.from_data_cleaned(data_cleaned, values='Value', stacks=data_cleaned[data_cleaned.Value > 0].groupby(['Country'])['Value'].sum().sort_values(ascending=False)[0:10], labels=['Country'])
    # add the presentation of the chart to the charts context
    #context['charts'].append(turnover_by_top_ten_country.get_presentation())

    #Top10Country = data_cleaned[data_cleaned.Value > 0].groupby(['Country'])['Value'].sum().sort_values(ascending=False)[0:10]

    #fig = plt.plot(figsize=(12, 12))
   # sns.barplot(x=Top10Country.values, y=Top10Country.index).set(xlabel='Value', ylabel='Country')

    # plotting number of orders per country
    Top10Country = data_cleaned[data_cleaned.Quantity > 0].groupby(['Country'])['Quantity'].sum().sort_values(
        ascending=False)[0:10]

    sns.barplot(x=Top10Country.values, y=Top10Country.index).set(xlabel='Quantity', ylabel='Country')
    data1 = {'x-data': Top10Country.index.tolist(), 'y-data': Top10Country.values.tolist()}

    # plotting turnover per country
    Top10Country = data_cleaned[data_cleaned.Quantity > 0].groupby(['Country'])['Value'].sum().sort_values(
        ascending=False)[0:10]
    # print(Top10Country.to_json())

    data2 = {'x-data': Top10Country.index.tolist(), 'y-data': Top10Country.values.tolist()}

    # plotting number of turnover per customers
    Top10Customers = data_cleaned[data_cleaned.Value > 0].groupby(['CustomerID', 'Country'])['Value'].sum().sort_values(
        ascending=False)[0:10]
    Top10Customers.sort_values().plot(kind='barh').set_title(
        'The Top10 Customers and their Country of Origin based on Value of Sales', fontsize=15)
    # print(Top10Country.to_json())

    data3 = {'x-data': Top10Customers.index.tolist(), 'y-data': Top10Customers.values.tolist()}
    # creating the pie chart of the percentage of sale value by theday of the week

    # creating the pie chart of the percentage of sale value by Month
    turnover_month = data_cleaned[data_cleaned.Value > 0].groupby(['InvoiceMonth'])['Value'].sum()
    turnover_month.plot(kind='pie').set_title('Percantages of Sales Value by Months', fontsize=15)

    data4 = {'x-data': turnover_month.index.tolist(), 'y-data': turnover_month.values.tolist()}
    data_cleaned.groupby('Day of week')['Value'].sum().plot(kind='pie', autopct='%.2f%%', figsize=(7, 7)).set(ylabel='')


    context = {
        'data1': data1,
        'data2': data2,
        'data3': data3,
        'data4': data4,
    }

    return render(request, 'customer/visualization.html', context)


# client ID search
def get_customer_id(request):
    """ this get search parameter from request and check for clients that have cid of the search param
        then return the str representation and id of the clients to be used in form
    """
    with open('customers/cust_seg_.csv', 'r') as f:
        reader = csv.reader(f)
        customers = list(reader)

    customer_param = request.GET.get('customer_param')
    customer_ids = [data[0] for data in customers if customer_param in data[0]]
    customer_data = []

    if customer_ids:
        for customer in customer_ids:
            customer_data.append({'id': customer, 'text': customer})

    print(customer_data, "customer_datacustomer_data")
    return JsonResponse(customer_data, safe=False)


def tables(request):
    # creating customer Id input from user
    customerid = request.GET.get('customerid')
    # Reading the dataset and preview
    data_cleaned = pd.read_csv('customers/cust_seg_cleaned.csv')
    # Converting my date attribute to date format
    data_cleaned['InvoiceDate'] = pd.to_datetime(data_cleaned['InvoiceDate'])

   # In[245]:

    print('{:,} rows; {:,} columns'
          .format(data_cleaned.shape[0], data_cleaned.shape[1]))
    print('{:,} transactions don\'t have a customer id'
          .format(data_cleaned[data_cleaned.CustomerID.isnull()].shape[0]))
    print('Transactions timeframe from {} to {}'.format(data_cleaned['InvoiceDate'].min(),
                                                        data_cleaned['InvoiceDate'].max()))


    # removing cancelled orders to remove negative figures
    data_cleaned = data_cleaned[data_cleaned['Quantity'] > 0]


    # In[247]:

    # viewing the shape of the dataset, the customers that are missing and the
    print('{:,} rows; {:,} columns'
          .format(data_cleaned.shape[0], data_cleaned.shape[1]))
    print('{:,} transactions don\'t have a customer id'
          .format(data_cleaned[data_cleaned.CustomerID.isnull()].shape[0]))
    print('Transactions timeframe from {} to {}'.format(data_cleaned['InvoiceDate'].min(),
                                                        data_cleaned['InvoiceDate'].max()))



    #### RECENCY FREQUENCY MONETARY_VALUE ##########

    # In[250]:

    ### RFM MODEEL ####
    # --Grouping  data by customerID--

    # Creating a snapshot date with plus 1 of the most recent date
    snapshot_date = data_cleaned['InvoiceDate'].max() + timedelta(days=1)
    # print(snapshot_date)
    # Grouping by CustomerID using the snapshot. The recencyu is the snapshot date minus the most recent date of the customer
    data_process = data_cleaned.groupby(['CustomerID']).agg({
                                                             'InvoiceDate': lambda x: (snapshot_date - x.max()).days,
                                                             'Invoice': 'count',
                                                             'Value': 'sum'})
    # Rename the columns
    data_process.rename(columns={'InvoiceDate': 'Recency',
                                 'Invoice': 'Frequency',
                                 'Value': 'MonetaryValue'}, inplace=True)

    print('{:,} rows; {:,} columns'
          .format(data_process.shape[0], data_process.shape[1]))
    # saving the new table for other models
    data = data_process

    # In[50]:


    # In[51]:

   # In[52]:

    # --Calculate R and F groups--
    # Create labels for Recency and Frequency
    r_labels = range(4, 0, -1);
    f_labels = range(1, 5)
    # Assigning these labels to 4 equal percentile groups
    r_groups = pd.qcut(data_process['Recency'], q=4, labels=r_labels)
    # Assign these labels to 4 equal percentile groups
    f_groups = pd.qcut(data_process['Frequency'], q=4, labels=f_labels)
    # Create new columns R and F
    data_process = data_process.assign(R=r_groups.values, F=f_groups.values)
    data_process.head(10)

    # In[53]:

    # Create labels for MonetaryValue
    m_labels = range(1, 5)
    # Assign these labels to three equal percentile groups
    m_groups = pd.qcut(data_process['MonetaryValue'], q=4, labels=m_labels)
    # Create new column M
    data_process = data_process.assign(M=m_groups.values)


    # In[55]:

    # Concat RFM quartile values to create RFM Segments
    def join_rfm(x):
        return str(x['R']) + str(x['F']) + str(x['M'])

    data_process['RFM_Segment_Concat'] = data_process.apply(join_rfm, axis=1)
    rfm = data_process

    # In[57]:

    # Count num of unique segments
    rfm_count_unique = rfm.groupby('RFM_Segment_Concat')['RFM_Segment_Concat'].nunique()
    # print(rfm_count_unique.sum())

    # In[58]:

    # Calculate RFM_Score
    rfm['RFM_Score'] = rfm[['R', 'F', 'M']].sum(axis=1)
    # print(rfm['RFM_Score'].head())

    # In[59]:

    # Define rfm_level function
    def rfm_level(df):
        if df['RFM_Score'] >= 9:
            return 'Can\'t Loose Them'
        elif ((df['RFM_Score'] >= 8) and (df['RFM_Score'] < 9)):
            return 'Champions'
        elif ((df['RFM_Score'] >= 7) and (df['RFM_Score'] < 8)):
            return 'Loyal'
        elif ((df['RFM_Score'] >= 6) and (df['RFM_Score'] < 7)):
            return 'Potential'
        elif ((df['RFM_Score'] >= 5) and (df['RFM_Score'] < 6)):
            return 'Promising'
        elif ((df['RFM_Score'] >= 4) and (df['RFM_Score'] < 5)):
            return 'Needs Attention'
        else:
            return 'Require Activation'

    # Create a new variable RFM_Level
    rfm['RFM_Level'] = rfm.apply(rfm_level, axis=1)

    # Searching for customer
    new = rfm.loc[rfm.index == customerid ]
    new_drop = new.drop('RFM_Segment_Concat', 1)

    # Print the aggregated dataset
    cust_search = new_drop
    # parsing the DataFrame in json format.
    cust_search_json_records = cust_search.reset_index().to_json(orient='records')

    cust_search_data = json.loads(cust_search_json_records)
    # parsing the result of the search into a table using json
    cust_search_result = cust_search.to_json(orient="split")
    cust_search_result_json = json.loads(cust_search_result)



    # In[60]:

    # Calculate average values for each RFM_Level, and return a size of each segment
    rfm_level_agg = rfm.groupby('RFM_Level').agg({
        'Recency': 'mean',
        'Frequency': 'mean',
        'MonetaryValue': ['mean', 'count']
    }).round(1)

    rfm_level_agg_new = rfm.groupby('RFM_Level').agg({'RFM_Level': 'max',
                                                    'Recency': 'mean',
                                                    'Frequency': 'mean',
                                                    'MonetaryValue': 'mean',
                                                    'RFM_Score': 'count'
                                                    }).round(1)
    # Print the aggregated dataset
    rfm_output = rfm_level_agg_new

    rfm_level_agg_chart = rfm.groupby(rfm.index).agg({'RFM_Level': 'max',
                                                    'Recency': 'mean',
                                                    'Frequency': 'mean',
                                                    'MonetaryValue': 'mean',
                                                    'RFM_Score': 'count'
                                                    }).round(1)

    # parsing the DataFrame in json format.
    #json_records = rfm_output.reset_index().to_json(orient='records')
    #data = []
   # data = json.loads(json_records)
    # print(data)
    # print(type(data))
    # In[61]:
    # RFM result Plot

    rfm_level_agg.columns = rfm_level_agg.columns.droplevel()
    rfm_level_agg.columns = ['RecencyMean', 'FrequencyMean', 'MonetaryMean', 'Count']
    #turnover_month = rfm_level_agg.columns
    #turnover_month.plot(kind='pie').set_title('Percantages of Sales Value by Months', fontsize=15)
    # Create our plot and resize it.

    # Customer by rFM_Level plot #Use polar area in chart.Js

    #num_customers_by_rfm_level = rfm_level_agg_chart.groupby(['RFM_Level'])['RFM_Score'].sum().sort_values(
    #    ascending=False)
    #num_customers_by_rfm_level.sort_values().plot(kind='pie').set_title(
    #    'The Top10 Customers and their Country of Origin based on Value of Sales', fontsize=15)

    """ 
    num_customers_by_rfm_level = rfm_level_agg_new.groupby('RFM_Level')['RFM_Score'].sum().plot(kind='pie', autopct='%.2f%%', figsize=(7, 7)).set(
        ylabel='')
    plt.title('Percentage of Customers by RFM_Level', fontsize=15)
    """
    #data1 = {'x-data': num_customers_by_rfm_level.index.tolist(), 'y-data': num_customers_by_rfm_level.values.tolist()}
    # Create our plot and resize it.


    # Parsing the RFM result into json format
    result = rfm_output.to_json(orient="split")
    rfm_json = json.loads(result)

    context = {
        "result": result,
        "rfm_output": rfm_output,
        "rfm_json": rfm_json,
        'cust_search_result_json': cust_search_result_json,
        'cust_search_result': cust_search_result,
        'cust_search': cust_search,
       # 'data1': data1

    }
    return render(request, 'customer/tables.html', context)


def clustering(request):
    #import matplotlib.pyplot as plt
    # creating customer Id input from user
    customerid = request.GET.get('customerid')

    # Reading the dataset and preview
    data_cleaned = pd.read_csv('customers/cust_seg_cleaned.csv')
    # Converting my date attribute to date format
    data_cleaned['InvoiceDate'] = pd.to_datetime(data_cleaned['InvoiceDate'])

    # In[245]:

    print('{:,} rows; {:,} columns'
          .format(data_cleaned.shape[0], data_cleaned.shape[1]))
    print('{:,} transactions don\'t have a customer id'
          .format(data_cleaned[data_cleaned.CustomerID.isnull()].shape[0]))
    print('Transactions timeframe from {} to {}'.format(data_cleaned['InvoiceDate'].min(),
                                                        data_cleaned['InvoiceDate'].max()))


    # removing cancelled orders to remove negative figures
    data_cleaned = data_cleaned[data_cleaned['Quantity'] > 0]


    #### RECENCY FREQUENCY MONETARY_VALUE ##########

    # In[250]:

   # --Grouping  data by customerID--

    # Creating a snapshot date with plus 1 of the most recent date
    snapshot_date = data_cleaned['InvoiceDate'].max() + timedelta(days=1)
    print(snapshot_date)
    # Grouping by CustomerID using the snapshot. The recencyu is the snapshot date minus the most recent date of the customer
    data_process = data_cleaned.groupby(['CustomerID']).agg({
                                                             'InvoiceDate': lambda x: (snapshot_date - x.max()).days,
                                                             'Invoice': 'count',
                                                             'Value': 'sum'})
    # Rename the columns
    data_process.rename(columns={'InvoiceDate': 'Recency',
                                 'Invoice': 'Frequency',
                                 'Value': 'MonetaryValue'}, inplace=True)

    print('{:,} rows; {:,} columns'
          .format(data_process.shape[0], data_process.shape[1]))
    # saving the new table for other models
    data = data_process


    ###### KMEANS ALGORITHM######
    # Normalizing the RFM scores to for accuracy using the saved table
    # norm_data_cleaned = np.log(data_cleaned['Value']+0.1)
    rfm_r_log = np.log(data['Recency'] + 0.1)  # log(0) is undefined
    rfm_f_log = np.log(data['Frequency'] + 0.1)
    rfm_m_log = np.log(data['MonetaryValue'] + 0.1)

    # loading the data into a dataframe
    log_data = pd.DataFrame({'MonetaryValue': rfm_m_log, 'Recency': rfm_r_log, 'Frequency': rfm_f_log})
    # storing the attributes to be used into a variable
    x = log_data.iloc[:, 0:3].values
    # building model for k=3
    #k_model = KMeans(n_clusters=5, random_state=42)
    # fit the model
    #k_model.fit(x)
    # predict the values
    #y_predicted = k_model.fit_predict(x)
    # add the new column to the dataframe
    #log_data['cluster'] = y_predicted

    # Visualizing 5 clusters
    km = KMeans(n_clusters=5)
    clusters_ = km.fit_predict(log_data.iloc[:, 0:3].values)
    log_data["cluster"] = clusters_

    # creating the subplot
    fig = plt.figure(figsize=(5, 5))
    ax = fig.add_subplot(111, projection='3d')
    ax.scatter(log_data.Recency[log_data.cluster == 0], log_data["MonetaryValue"][log_data.cluster == 0],
               log_data["Frequency"][log_data.cluster == 0], c='red', s=5, label='cluster0')
    ax.scatter(log_data.Recency[log_data.cluster == 1], log_data["MonetaryValue"][log_data.cluster == 1],
               log_data["Frequency"][log_data.cluster == 1], c='purple', s=5, label='cluster1')
    ax.scatter(log_data.Recency[log_data.cluster == 2], log_data["MonetaryValue"][log_data.cluster == 2],
               log_data["Frequency"][log_data.cluster == 2], c='gold', s=5, label='cluster2')
    ax.scatter(log_data.Recency[log_data.cluster == 3], log_data["MonetaryValue"][log_data.cluster == 3],
               log_data["Frequency"][log_data.cluster == 3], c='green', s=5, label='cluster3')
    ax.scatter(log_data.Recency[log_data.cluster == 4], log_data["MonetaryValue"][log_data.cluster == 4],
               log_data["Frequency"][log_data.cluster == 4], c='blue', s=5, label='cluster4')
    ax.scatter(km.cluster_centers_[:,1], km.cluster_centers_[:,2],km.cluster_centers_[:,0],s=20,marker='s', c='black', alpha=0.7, label='Centroids')

    #ax.view_init(30, 185)
    plt.xlabel("Recency")
    plt.ylabel("MonetaryValue")
    ax.set_zlabel('Frequency')
    plt.title('Cluster Plot with K-Means Model')
    plt.legend()
    #plt.show()

    # Calculate average values for each cluster for 5 clusters
    cluster = log_data.groupby('cluster').agg({'cluster': 'max',
                                             'Recency': 'mean',
                                             'Frequency': 'mean',
                                             'MonetaryValue': ['mean', 'count']
                                             }).round(2)
    km_output = cluster
    # Parsing the RFM result into json format
    output = km_output.to_json(orient="split")
    km_json = json.loads(output)


    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()

    kmeans_model = base64.b64encode(image_png)
    kmeans_model = kmeans_model.decode('utf-8')


    # barplot of the cluster size
    cluster_size_plot = log_data.groupby('cluster')['cluster'].count()
    sns.barplot(y=cluster_size_plot.values, x=cluster_size_plot.index).set(xlabel='Count of', ylabel='RFM Level')
    data2 = {'x-data': cluster_size_plot.index.tolist(), 'y-data': cluster_size_plot.values.tolist()}

    # Searching for customer
    cust_search = log_data.loc[log_data.index == customerid]

    # parsing the DataFrame in json format.
    cust_search_json_records = cust_search.reset_index().to_json(orient='records')

    cust_search_data = json.loads(cust_search_json_records)
    # parsing the result of the search into a table using json
    cust_search_result = cust_search.to_json(orient="split")
    cust_search_result_json = json.loads(cust_search_result)

    context = {
       # 'data1': data1,
        'data2': data2,
        'kmeans_model': kmeans_model,
        'km_json': km_json,
        'cust_search_result_json': cust_search_result_json,
        'cust_search_result': cust_search_result,
        'cust_search': cust_search,

    }

    return render(request, 'customer/clustering.html', context)

def prediction(request):
    from pandas import Timestamp
    # Reading the dataset and preview
    data_cleaned = pd.read_csv('customers/cust_seg_cleaned.csv')
    # Converting my date attribute to date format
    data_cleaned['InvoiceDate'] = pd.to_datetime(data_cleaned['InvoiceDate'])

    # removing cancelled orders to remove negative figures
    data_cleaned = data_cleaned[data_cleaned['Quantity'] > 0]

    ####TIME SERIES FORECASTING

    data_cleaned['InvoiceDate'] = pd.to_datetime(data_cleaned['InvoiceDate'], format='%Y-%m-%d %H:%M').dt.strftime(
        '%Y-%m-%d')
    data_cleaned['InvoiceDate'] = pd.to_datetime(data_cleaned['InvoiceDate'], format='%Y-%m-%d')

    ts_data = data_cleaned[data_cleaned.Value > 0].groupby('InvoiceDate')['Value'].sum().reset_index()
    ts_data = ts_data.set_index('InvoiceDate')

    #y = ts_data['Value'].resample('MS').mean()

    # Creating train and test set
    # Index 766562 marks 80% of the dataset
    train = ts_data[0:544]
    test = ts_data[544:]

    train['InvoiceDate'] = pd.to_datetime(train.index, format='%d-%m-%Y %H:%M')
    train.index = train.InvoiceDate
    train = train.resample('D').mean()
    test['InvoiceDate'] = pd.to_datetime(test.index, format='%d-%m-%Y %H:%M')
    test.index = test.InvoiceDate
    test = test.resample('D').mean()

    train.Value.plot(figsize=(15, 8), title='Daily Sales Value', fontsize=14)
    #test.Value.plot(figsize=(15, 8), title='Daily Sales Value', fontsize=14)
   # plt.savefig('time-series.png')

    dd = np.asarray(train.Value)
    y_hat = test.copy()
    y_hat['naive'] = dd[len(dd) - 1]
    plt.figure(figsize=(12, 8))
    plt.plot(train.index, train['Value'], label='Train')
    #plt.plot(test.index, test['Value'], label='Test')
    #plt.plot(y_hat.index, y_hat['naive'], label='Naive Forecast')
    plt.legend(loc='best')
    plt.title("Naive Forecast")
   # plt.savefig('time-series-naive-approach.png')

   # data = {'x-data': y.index.tolist(), 'y-data': y.values.tolist()}

    # resampling to get the weekly sales and returns
    WeeklySale = data_cleaned[data_cleaned['Value'] > 0].Value.resample('W').sum()
    WeeklyRet = data_cleaned[data_cleaned['Quantity'] < 0].Quantity.resample('W').sum().abs()
    # creating the subplot
    fig, [ax1, ax2] = plt.subplots(nrows=1, ncols=2, figsize=(15, 5))
    WeeklySale.plot(ax=ax1).set(xlabel="Month", ylabel="Quantity")
    ax1.set_title("Weekly Sales by Quantity", fontsize=15)
    WeeklyRet.plot(ax=ax2).set(xlabel="Month", ylabel="Quantity")
    ax2.set_title("Weekly Returns Quantity", fontsize=15)
    #plt.show()

    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()

    timeseries_model = base64.b64encode(image_png)
    timeseries_model = timeseries_model.decode('utf-8')



    context = {
       # 'data':data,
        'timeseries_model': timeseries_model,


    }

    return render(request, 'customer/prediction.html', context)