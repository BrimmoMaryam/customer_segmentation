from django.urls import path
from django.conf.urls import include
from . import views
from .views import mainpage, visualization, get_customer_id, tables, clustering,prediction


urlpatterns = [
    path('', mainpage, name='mainpage'),
    path('visualization', visualization, name='visualization'),
    path('custsearch', get_customer_id, name='get_customer_id'),
    #path('get_quantity_by_country', get_quantity_by_country, name='get_quantity_by_country'),
    #path('get_turnover_by_country', get_turnover_by_country, name='get_turnover_by_country'),
    #path('get_turnover_by_customer_by_country', get_turnover_by_customer_by_country, name='get_turnover_by_customer_by_country'),
    #path('get_turnover_by_month', get_turnover_by_month, name='get_turnover_by_month'),
    path('tables', tables, name='tables'),
    path('clustering', clustering, name='clustering'),
    path('prediction', prediction, name='prediction'),
    #path('get_num_customers_by_rfm_level', get_num_customers_by_rfm_level, name='get_num_customers_by_rfm_level')


    #path('django_plotly_dash/', include('django_plotly_dash.urls')),
]